<template>
  <div>
    <h1>Bienvenidos a Infonet</h1>
    <div class="offers">
      <div v-for="offer in offers" :key="offer.titulo" class="offer-card">
        <h2>{{ offer.titulo }}</h2>
        <p>{{ offer.descripcion }}</p>
      </div>
    </div>
    <section>
      <h2>Comentarios de los Clientes</h2>
      <div v-if="comments.length > 0">
        <ul>
          <li v-for="(comment, index) in comments" :key="index">
            <p><strong>{{ comment.nombre }}:</strong> {{ comment.descripcion }}</p>
          </li>
        </ul>
      </div>
      <div v-else>
        <p>No hay comentarios disponibles.</p>
      </div>
    </section>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      offers: [],
      comments: []
    };
  },
  async mounted() {
    try {
      const response = await axios.get('https://raw.githubusercontent.com/shaka0241/infonet_api/main/home.json');
      this.offers = response.data.planes;
      this.comments = response.data.feedback;
    } catch (error) {
      console.error('Error al cargar las ofertas o comentarios:', error);
    }
  }
};
</script>

<style scoped>
.offers {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

.offer-card {
  border: 1px solid #ddd;
  padding: 16px;
  border-radius: 8px;
  width: 300px;
  text-align: center;
  background-color: #fff;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.offer-card h2 {
  margin-bottom: 10px;
}

.offer-card p {
  color: #666;
}

section {
  margin-top: 40px;
}

@media (max-width: 600px) {
  .offers, .offer-card {
    width: 100%;
    padding: 10px;
  }
}
</style>
