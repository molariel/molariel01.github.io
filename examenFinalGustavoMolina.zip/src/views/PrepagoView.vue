<template>
  <div class="prepago-container">
    <h1>Productos Prepago</h1>
    <div class="products-grid">
      <ProductCard v-for="product in products" :key="product.id" :product="product" />
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import ProductCard from '../components/ProductCard.vue';

export default {
  name: 'PrepagoView',
  components: { ProductCard },
  data() {
    return {
      products: []
    };
  },
  async mounted() {
    try {
      const response = await axios.get('https://raw.githubusercontent.com/shaka0241/infonet_api/main/productos.json');
      this.products = response.data.productos;
    } catch (error) {
      console.error('Error al cargar los productos:', error);
    }
  }
};
</script>

<style scoped>
.prepago-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.products-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

@media (max-width: 768px) {
  .prepago-container {
    padding: 10px;
  }
}
</style>
