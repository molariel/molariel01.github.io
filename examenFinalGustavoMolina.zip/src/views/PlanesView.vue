<template>
    <div>
      <h1>Planes</h1>
      <div class="plans-grid">
        <div v-for="plan in plans" :key="plan.titulo" class="plan-card">
          <h2>{{ plan.titulo }}</h2>
          <p>{{ plan.descripcion }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'PlanesView',
    data() {
      return {
        plans: []
      };
    },
    async mounted() {
      try {
        const response = await axios.get('https://raw.githubusercontent.com/shaka0241/infonet_api/main/home.json');
        this.plans = response.data.planes;
      } catch (error) {
        console.error('Error al cargar los planes:', error);
      }
    }
  };
  </script>
  
  <style scoped>
  .plans-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
  }
  
  .plan-card {
    border: 1px solid #ddd;
    padding: 16px;
    border-radius: 8px;
    width: 300px;
    text-align: center;
    background-color: #fff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
  
  .plan-card h2 {
    margin-bottom: 10px;
  }
  
  .plan-card p {
    color: #666;
  }
  
  @media (max-width: 600px) {
    .plans-grid, .plan-card {
      width: 100%;
      padding: 10px;
    }
  }
  </style>
  