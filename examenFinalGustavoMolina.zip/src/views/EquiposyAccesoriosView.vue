<template>
  <div class="container">
    <div class="products-container">
      <h1>Equipos y Accesorios</h1>
      <div class="products-grid">
        <ProductCard v-for="product in products" :key="product.id" :product="product" @add-to-cart="addToCart" />
      </div>
    </div>
    <div class="cart-container">
      <CartApp :cart="cart" @checkout="goToCheckout" />
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import ProductCard from '../components/ProductCard.vue';
import CartApp from '../components/CartApp.vue';

export default {
  components: { ProductCard, CartApp },
  data() {
    return {
      products: [],
      cart: []
    };
  },
  async mounted() {
    try {
      const response = await axios.get('https://raw.githubusercontent.com/shaka0241/infonet_api/main/productos.json');
      this.products = response.data.productos;
    } catch (error) {
      console.error('Error al cargar los productos:', error);
    }
  },
  methods: {
    addToCart(product) {
      this.cart.push(product);
    },
    goToCheckout() {
      this.$router.push('/pagar');
    }
  }
};
</script>

<style scoped>
.container {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  padding: 20px;
}

.products-container {
  flex: 3;
  margin-right: 20px;
}

.cart-container {
  flex: 1;
  min-width: 300px;
}

.products-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

@media (max-width: 768px) {
  .container {
    flex-direction: column;
  }

  .products-container {
    margin-right: 0;
    margin-bottom: 20px;
  }

  .cart-container {
    min-width: 100%;
  }
}
</style>
