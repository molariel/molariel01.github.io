<template>
  <div>
    <h1>Confirmación</h1>
    <div v-if="orderDetails">
      <p>Orden # {{ orderDetails.orderNumber }}</p>
      <p>Estado: {{ orderDetails.status }}</p>
    </div>
    <div v-else>
      <p>Cargando detalles de la orden...</p>
    </div>
    <router-link to="/">
      <button>Volver a Home</button>
    </router-link>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      orderDetails: null
    };
  },
  async mounted() {
    this.fetchOrderDetails();
  },
  methods: {
    async fetchOrderDetails() {
      try {
        const response = await axios.get('https://raw.githubusercontent.com/shaka0241/infonet_api/main/ordercheckresp.json');
        this.orderDetails = response.data;
      } catch (error) {
        console.error('Error al obtener los detalles de la orden:', error);
      }
    }
  }
};
</script>

<style scoped>
button {
  margin-top: 20px;
  padding: 10px 20px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
button:hover {
  background-color: #0056b3;
}
</style>
