<template>
    <div>
      <h1>404 - Página No Encontrada</h1>
      <router-link to="/">Volver al Inicio</router-link>
    </div>
  </template>
  
  <script>
  export default {};
  </script>
  
  <style scoped>
  h1 {
    color: red;
  }
  </style>
  