<template>
  <div class="payment-container">
    <h2>Detalles del despacho</h2>
    <form @submit.prevent="submitOrder">
      <div class="form-group">
        <label for="name">Nombre:</label>
        <input id="name" v-model="name" required>
      </div>
      <div class="form-group">
        <label for="address">Dirección:</label>
        <input id="address" v-model="address" required>
      </div>
      <div class="form-group">
        <label for="email">Correo Electrónico:</label>
        <input id="email" type="email" v-model="email" @input="validateConfirmEmail" required>
        <span v-if="emailError" class="error">{{ emailError }}</span>
      </div>
      <div class="form-group">
        <label for="confirmEmail">Repetir Correo Electrónico:</label>
        <input id="confirmEmail" type="email" v-model="confirmEmail" @input="validateConfirmEmail" required>
        <span v-if="confirmEmailError" class="error">{{ confirmEmailError }}</span>
      </div>
      <div class="form-group">
        <label for="phone">Teléfono:</label>
        <input id="phone" type="tel" v-model="phone" @input="validatePhone" required>
        <span v-if="phoneError" class="error">{{ phoneError }}</span>
      </div>
      <h2>Forma de Pago</h2>
      <div class="form-group">
        <label for="paymentMethod">Método de Pago:</label>
        <select id="paymentMethod" v-model="paymentMethod" required>
          <option value="credit-card">Tarjeta de Crédito</option>
          <option value="paypal">PayPal</option>
          <option value="bank-transfer">Transferencia Bancaria</option>
        </select>
      </div>
      <button type="submit" class="submit-button">Confirmar</button>
      <span v-if="formError" class="error">{{ formError }}</span>
    </form>
  </div>
</template>

<script>
export default {
  name: 'PaymentView',
  data() {
    return {
      name: '',
      address: '',
      email: '',
      confirmEmail: '',
      phone: '',
      paymentMethod: 'credit-card',
      emailError: '',
      confirmEmailError: '',
      phoneError: '',
      formError: ''
    };
  },
  methods: {
    validateConfirmEmail() {
      this.confirmEmailError = this.email === this.confirmEmail ? '' : 'Los correos electrónicos no coinciden.';
    },
    validatePhone() {
      const phonePattern = /^[0-9]{8}$/;
      this.phoneError = phonePattern.test(this.phone) ? '' : 'Número de teléfono no válido, deben ser 8 números.';
    },
    submitOrder() {
      this.validateConfirmEmail();
      this.validatePhone();

      if (this.confirmEmailError || this.phoneError) {
        this.formError = 'Por favor, corrige los errores antes de enviar el formulario.';
        return;
      }

      this.$router.push('/confirmacion');
    }
  }
};
</script>

<style scoped>
.payment-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h2 {
  margin-bottom: 20px;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
  color: #555;
}

input, select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

input:focus, select:focus {
  outline: none;
  border-color: #007bff;
}

.error {
  color: red;
  font-size: 0.9em;
}

.submit-button {
  display: block;
  width: 100%;
  padding: 15px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.submit-button:hover {
  background-color: #0056b3;
}

@media (max-width: 600px) {
  .payment-container {
    padding: 15px;
  }
}
</style>
