<template>
  <div id="app">
    <NavBar />
    <router-view />
  </div>
</template>

<script>
import NavBar from './components/NavBar.vue';

export default {
  components: {
    NavBar
  }
};
</script>

<style>
body {
  margin: 0;
  font-family: 'Roboto', sans-serif;
  background-color: #f5f5f5;
  color: hsl(231, 32%, 9%);
}

a {
  color: inherit;
  text-decoration: none;
  transition: color 0.3s;
}

a:hover {
  color: #0d74e9;
}

button {
  font-size: 1rem;
  transition: background-color 0.3s, transform 0.2s;
}

button:active {
  transform: scale(0.98);
}

h1, h2, h3, h4, h5, h6 {
  margin: 0;
  font-weight: normal;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.center {
  text-align: center;
}

.text-bold {
  font-weight: bold;
}

.text-muted {
  color: #6c757d;
}

@media (max-width: 600px) {
  .container {
    padding: 0 10px;
  }
}
</style>
