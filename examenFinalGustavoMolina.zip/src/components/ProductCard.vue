<template>
  <div class="card">
    <h3>{{ product.nombre }}</h3>
    <ul>
      <li v-for="caracteristica in product.caracteristicas" :key="caracteristica">{{ caracteristica }}</li>
    </ul>
    <p>Precio Normal: {{ product.precio_normal  }}</p>
    <p>Precio Infonet: {{ product.precio_infonet  }}</p>
    <button @click="$emit('add-to-cart', product)">Agregar al carrito</button>
  </div>
</template>

<script>
export default {
  props: {
    product: {
      id: '',
      nombre: '',
      caracteristicas: [],
      precio_normal: 0,
      precio_infonet: 0
    }
  }
};
</script>

<style scoped>
.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  text-align: center;
  background-color: #fff;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 300px;
}

.card h3 {
  margin-bottom: 10px;
}

.card ul {
  list-style-type: none;
  padding: 0;
}

.card p {
  margin: 5px 0;
  color: #666;
}

.card button {
  margin-top: 10px;
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.card button:hover {
  background-color: #0056b3;
}
</style>
