<template>
  <nav class="navbar">
    <button class="toggle-button" @click="toggleMenu">☰</button>
    <div :class="{'nav-items': true, 'nav-items--visible': isMenuVisible}">
      <router-link to="/" class="nav-item" @click="hideMenu">Home</router-link>
      <router-link to="/equiposyaccesorios" class="nav-item" @click="hideMenu">Equipos y Accesorios</router-link>
      <router-link to="/planes" class="nav-item" @click="hideMenu">Planes</router-link>
      <router-link to="/prepago" class="nav-item" @click="hideMenu">Prepago</router-link>
    </div>
  </nav>
</template>

<script>
export default {
  data() {
    return {
      isMenuVisible: false
    };
  },
  methods: {
    toggleMenu() {
      this.isMenuVisible = !this.isMenuVisible;
    },
    hideMenu() {
      this.isMenuVisible = false;
    }
  }
};
</script>

<style scoped>
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  padding: 1em;
  flex-wrap: wrap;
}

.toggle-button {
  background-color: #333;
  color: white;
  border: none;
  font-size: 1.5em;
  cursor: pointer;
  display: none;
}

.nav-items {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  width: 100%;
}

.nav-item {
  color: white;
  text-decoration: none;
  margin: 0.5em;
}

.nav-item:hover {
  text-decoration: underline;
}

@media (max-width: 600px) {
  .toggle-button {
    display: block;
  }

  .nav-items {
    display: none;
    flex-direction: column;
    align-items: center;
  }

  .nav-items--visible {
    display: flex;
  }
}
</style>
