<template>
  <div class="cart">
    <h2>Carrito de Compras Infonet</h2>
    <ul>
      <li v-for="item in cart" :key="item.id">
        <p>{{ item.nombre }} - {{ item.precio_infonet }}</p>
      </li>
    </ul>
    <div class="totals">
      <p><strong>Subtotal Productos:</strong> {{ total }}</p>
      <p><strong>Descuentos:</strong> {{ discount }}</p>
      <p><strong>Total:</strong> {{ finalAmount }}</p>
    </div>
    <button @click="checkout">PAGAR</button>
  </div>
</template>

<script>
export default {
  props: ['cart'],
  computed: {
    total() {
      return this.cart.reduce((sum, item) => sum + item.precio_infonet, 0);
    },
    discount() {
      return this.total >= 1000000 ? this.total * 0.09 : this.total * 0.03;
    },
    finalAmount() {
      return this.total - this.discount;
    }
  },
  methods: {
    checkout() {
      this.$emit('checkout');
    }
  }
};
</script>

<style scoped>
.cart {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  background-color: #fff;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.cart h2 {
  margin-bottom: 10px;
}

.cart ul {
  list-style-type: none;
  padding: 0;
}

.cart li {
  margin-bottom: 10px;
}

.cart .totals {
  border-top: 1px solid #ddd;
  padding-top: 10px;
  margin-top: 10px;
}

.cart p {
  margin: 5px 0;
  color: #666;
}

.cart button {
  margin-top: 20px;
  padding: 10px 20px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width: 100%;
}

.cart button:hover {
  background-color: #0056b3;
}
</style>
