import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import EquiposyAccesoriosView from '../views/EquiposyAccesoriosView.vue';
import PaymentView from '../views/PaymentView.vue';
import ConfirmacionView from '../views/ConfirmacionView.vue';
import PlanesView from '../views/PlanesView.vue';
import PrepagoView from '../views/PrepagoView.vue';
import NotFound from '../views/NotFound.vue';

const routes = [
  { path: '/', component: HomeView },
  { path: '/equiposyaccesorios', component: EquiposyAccesoriosView },
  { path: '/planes', component: PlanesView },
  { path: '/prepago', component: PrepagoView },
  { path: '/pagar', component: PaymentView },
  { path: '/confirmacion', component: ConfirmacionView },
  { path: '/:catchAll(.*)', component: NotFound }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
